# Supplementary material: the code behind every result

This archive holds the code that produces the results, not the code that assembles the paper. Each experiment
writes one CSV or JSON per run into `results/` (created on first run); the tables and figures of the paper are
written from those files by the generators, which are not part of this archive.

## How to run

Every script is standalone and is run from this directory:

    PLATONIC_ROOT=<cache root> PLATONIC_RESULTS=results python3 scripts/<script>.py

`PLATONIC_ROOT` points at the directory holding the cached features and centroids (`results/centroids/...`,
`results/text_cache/...`); `PLATONIC_RESULTS` is where the outputs are written. Scripts that extract features
also read the image datasets and download the model weights through `timm` or `transformers`; the rest read only
the caches. Seeds are fixed inside each script.

## The instrument on its own

`tool/` ships the calibrated reading as one script: `calibrated_delta.py` (the estimator, the spectrum-matched
null and the excess), `demo.py` (a worked example on the provided labels), `run_checks.py` (its self-test), and
the example label files for the WordNet-30 and CIFAR-100 groupings. It reproduces any cell of the census from a
centroid matrix, without the rest of the pipeline.

## What each script produces

| script | reported in | models | datasets | writes |
|---|---|---|---|---|
| `scripts/exp10_local_vs_global.py` | Figure 5, Table 4, Table 5, Whose tree | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `exp10_local_vs_global.csv` |
| `scripts/exp14_dbpedia_text.py` | Table 18, Table 19, Table 20 | BGE, E5, GTE | DBpedia | `exp14_dbpedia.csv` |
| `scripts/exp16_hierarcaps.py` | Table 18, Table 19, Table 20 | BGE, CLIP, E5, GTE, SigLIP | HierarCaps | `exp16_hierarcaps.csv` |
| `scripts/exp17_wordnet_prompts.py` | Table 21 | BGE, E5, GPT-2 | -- | `exp17_wordnet_prompts.csv` |
| `scripts/exp18_text_nulls.py` | Table 21 | BGE, E5, GPT-2, GTE, OLMo, Pythia | -- | `exp18_text_nulls.csv` |
| `scripts/exp1_delta_controls.py` | Table 2, Table 3, Table 18, Table 19, Table 20, Implications for Hyperbolic Representation Learning | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | ImageNet | `exp1_delta_controls.csv` |
| `scripts/exp20_null_ztable.py` | Table 4, Table 5, Table 22, Table 23 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `exp20_null_ztable.csv` |
| `scripts/exp21b_local_global_K200.py` | Table 17 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | ImageNet | `exp21b_local_global_K200.csv` |
| `scripts/exp22_tree_similarity.py` | Table 16 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `exp22_tree_similarity_imagenet.npz` |
| `scripts/exp23_treemap_controls.py` | Figure 5, Table 16, Whose tree | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `exp23_config_diagnostics.json, exp23_treemap_controls.npz` |
| `scripts/exp24_val_metric_selection.py` | Table 22, Table 23 | CLIP, DINOv2, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `exp24_val_metric_selection.csv` |
| `scripts/exp27_dbpedia_treemap.py` | Table 18, Table 19, Table 20 | BGE, E5, GTE | DBpedia | `exp27_dbpedia_treemap.json` |
| `scripts/exp2_metric_controls.py` | Figure 9, Table 22, Table 23 | CLIP, DINOv2, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `exp2_metric_controls.csv` |
| `scripts/exp2b_normalized_stack.py` | Table 22, Table 23 | CLIP, DINOv2, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `exp2b_normalized_stack.csv` |
| `scripts/exp3_semantic_alignment.py` | Table 18, Table 19, Table 20, Whose tree | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `exp3_alignment.csv` |
| `scripts/exp4_prompt_variation.py` | Table 21 | BGE, E5, GPT-2 | ImageNet | `exp4_prompt_variation.csv` |
| `scripts/exp8_audit.py` | Table 18, Table 19, Table 20 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `exp8_p1_recovery.csv, exp8_p6_pooling.csv` |
| `scripts/expR39c_census200_cache.py` | Table 4, Table 5 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `expR39c_census200_cache.csv` |
| `scripts/expR40b_p999census200.py` | Table 4, Table 5 | CLIP, DINO-B, DINOv2, E5, SigLIP, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `expR40b_p999census200.csv` |
| `scripts/expR42_star_calibration.py` | Table 2, Table 3, Structure beyond the second moments at the class level | -- | -- | `expR42_star_calibration.csv` |
| `scripts/expR45_convnet_rows.py` | Table 4, Table 5 | BYOL, Barlow Twins | ImageNet | `expR45_convnet_rows.csv` |
| `scripts/expR47_extraction_variance.py` | Table 21, Conclusion and Limitations | GPT-2, OLMo | -- | `expR47_extraction_variance.csv` |
| `scripts/expR48b_text_census200_bs1.py` | Table 21 | BGE, E5, GPT-2, GTE, OLMo, Pythia | -- | `expR48b_text_census200_bs1.csv` |
| `scripts/expR49_template_nulls_bs1.py` | Table 21 | GPT-2 | -- | `expR49_template_nulls_bs1.csv` |
| `scripts/expR52_census_haar_p999_200.py` | Figure 4, Table 4, Table 5, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Structure beyond the second moments at the class level | CLIP, DINO-B, DINOv2, E5, SigLIP, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `expR52_census_haar_p999_200.csv` |
| `scripts/expR53_text_haar_p999_200.py` | Figure 4, Table 21, Whose tree | BGE, E5, GPT-2, GTE, OLMo, Pythia | -- | `expR53_text_gauss_p999_200.csv, expR53_text_haar_p999_200.csv, expR53_text_haar_sup_200.csv` |
| `scripts/expR54_census_haar_sup_200.py` | Table 4, Table 5 | -- | -- | `expR54_census_haar_sup_200.csv` |
| `scripts/expR55_depth_power.py` | Table 15 | -- | -- | `expR55_depth_power.csv` |
| `scripts/expR55b_depth_power_leafframe.py` | Table 15 | -- | -- | `expR55b_depth_power_leafframe.csv` |
| `scripts/expR56_depth_variants.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Hierarchy above the labelled clusters | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `expR56_depth_variants.csv` |
| `scripts/expR57_census_cosine.py` | Table 4, Table 5, Table 21 | BGE, CLIP, DINO-B, DINOv2, E5, GPT-2 | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `expR57_census_cosine_haar_p999_200.csv, expR57_text_cosine_haar_p999_200.csv` |
| `scripts/expR58_treemap_cutfree.py` | Figure 5, Table 16 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, ImageNet | `expR58_treemap_cutfree.csv, expR58_treemap_cutfree_summary.csv` |
| `scripts/expR59_imagenet_bootstrap.py` | Table 8 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | ImageNet | `expR59_imagenet_bootstrap_summary.csv` |
| `scripts/expR60_c_sweep_record.py` | Table 8 | CLIP, DINOv2 | ImageNet | `expR60_c_sweep_record.csv` |
| `scripts/expR61_dbpedia_record.py` | Table 18, Table 19, Table 20 | BGE, E5, GTE | DBpedia | `expR61_dbpedia_record.csv` |
| `scripts/expR62_samplelevel_record.py` | Figure 3, Table 7, The premise at the sample level | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, DTD | `expR62_samplelevel_record.csv` |
| `scripts/expR63_meru_record.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Hierarchy above the labelled clusters | CLIP, MERU | CIFAR-100, ImageNet | `expR63_meru_record.csv` |
| `scripts/expR64_implanted_depth.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Hierarchy above the labelled clusters | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | ImageNet | `expR56_depth_variants.csv` |
| `scripts/expR64b_implanted_depth_v2.py` | Figure 7, Figure 8, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Table 15, Hierarchy above the labelled clusters | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | ImageNet | `expR64b_wn30.csv, expR64b_wn30_summary.csv, expR64b_wn30bal_summary.csv, expR67_frame_choice.json` |
| `scripts/expR65_hier_finetune.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14 | CLIP, augreg ViT-B, supervised ViTs | ImageNet | `expR65_hier_finetune.csv` |
| `scripts/expR66_joint_sensitivity.py` | Figure 4, Table 4, Table 5, Table 8, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Structure beyond the second moments at the class level | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-10, CIFAR-100, DTD, FMNIST, ImageNet, MNIST | `expR52_census_haar_p999_200.csv, expR66_joint_sensitivity_summary.csv` |
| `scripts/expR66c_joint_sensitivity.py` | Figure 2, Table 4, Table 5, Table 8, Spectrum-matched null, excess and genuineness | -- | CIFAR-100, ImageNet | `expR66c_joint_sensitivity_summary.csv, expR75_census_centered_haar.csv` |
| `scripts/expR68_corollary_excess.py` | Figure 4, Figure 9, Table 4, Table 5, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Table 22, Table 23, Hierarchy above the labelled clusters, Structure beyond the second moments at the class level | CLIP, DINOv2, supervised ViTs | CIFAR-10, CIFAR-100, DTD, ImageNet | `correlation_cis.csv, exp2_metric_controls.csv, expR52_census_haar_p999_200.csv, expR56_depth_variants.csv` |
| `scripts/expR69_depth_haarhubs.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Table 15 | -- | -- | `expR69_depth_haarhubs_summary.csv` |
| `scripts/expR70_inet1k_supervised.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Table 18, Table 19, Table 20, Hierarchy above the labelled clusters | DeiT, augreg ViT-B, supervised ViTs | CIFAR-100, ImageNet | `expR70_inet1k_supervised.csv` |
| `scripts/expR71_meru_radii.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14 | E5, MERU | CIFAR-100, ImageNet | `expR71_meru_radii.csv` |
| `scripts/expR72_budget_record.py` | Figure 4, Figure 6, Table 4, Table 5, Table 8, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Structure beyond the second moments at the class level | CLIP, DINOv2, E5, supervised ViTs | CIFAR-100, DTD, ImageNet | `expR52_census_haar_p999_200.csv, expR72_budget_record.csv, expR72_budget_record_summary.csv` |
| `scripts/expR73_transfer_bootstrap_record.py` | Table 8 | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | CIFAR-100, DTD | `expR73_transfer_bootstrap_record_summary.csv` |
| `scripts/expR74_decoupling.py` | Figure 2, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Hierarchy above the labelled clusters | -- | ImageNet | `expR56_depth_variants.csv, expR74_decoupling_summary.csv` |
| `scripts/expR75_census_centered_haar.py` | Figure 2, Figure 4, Table 4, Table 5, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Spectrum-matched null, excess and genuineness, Structure beyond the second moments at the class level | -- | -- | `expR52_census_haar_p999_200.csv, expR75_census_centered_haar.csv` |
| `scripts/expR77_positive_control_tests.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Table 15, Hierarchy above the labelled clusters | supervised ViTs | ImageNet | `expR67_frame_choice.json, expR77_positive_control.csv, expR77_positive_control_verdict.json` |
| `scripts/expR78_khrulkov_replication.py` | Figure 3, Table 6, Table 7, The premise at the sample level | ResNet-34 | CIFAR-10, CIFAR-100, CUB-200, ImageNet, MiniImageNet | `expR78_khrulkov_replication.csv, expR78_khrulkov_replication_summary.csv` |
| `scripts/expR79_synthetic_deep_poincare.py` | Figure 8, Table 15, Hierarchy above the labelled clusters | supervised ViTs | ImageNet | `expR64b_wn30_summary.csv, expR79_synthetic_deep_poincare.csv` |
| `scripts/expR80_implanted_alignment.py` | Table 15 | CLIP | ImageNet | `expR80_decision.csv, expR80_implanted_alignment.csv` |
| `scripts/expR81_deep_per_backbone.py` | Figure 2, Figure 8, Table 15, Hierarchy above the labelled clusters | CLIP, DINO-B, DINOv2, SigLIP, supervised ViTs | ImageNet | `expR64b_wn30_summary.csv, expR81_deep_per_backbone.csv, expR81_deep_per_backbone_summary.csv` |
| `scripts/expR82_radial_control.py` | Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Hierarchy above the labelled clusters | DINOv2, supervised ViTs | -- | `expR56_depth_variants.csv, expR82_radial_control.csv, expR82_radial_control_summary.csv` |
| `scripts/expR83_flat_balanced.py` | Figure 8, Table 9, Table 10, Table 11, Table 12, Table 13, Table 14, Table 15, Hierarchy above the labelled clusters | supervised ViTs | ImageNet | `expR64b_wn30_summary.csv, expR67_frame_choice.json, expR83_flat_balanced.csv, expR83_flat_balanced_summary.csv` |
| `scripts/expR84_tree_ceiling.py` | Figure 5, Table 16 | -- | ImageNet | `exp23_config_diagnostics.json, expR84_tree_ceiling.csv, expR84_tree_ceiling_summary.csv` |
| `scripts/expR85_khrulkov_sup.py` | Figure 3, Table 6 | ResNet-34 | -- | `expR85_khrulkov_sup.csv, expR85_khrulkov_sup_summary.csv` |

59 experiment scripts, 0 shared helpers, plus `tool/`.

`scripts/palette.py` and `scripts/style.mplstyle` are the colours and the matplotlib style of the paper's figures; `expR64_implanted_depth.py` and `expR64b_implanted_depth_v2.py` import them for the diagnostic plot they draw after writing their CSV, and `expR55_depth_power.py` and `expR55b_depth_power_leafframe.py` use the style when it is present.
